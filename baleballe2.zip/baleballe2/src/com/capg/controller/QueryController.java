package com.capg.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.capg.dto.Queryy;
import com.capg.service.QueryService;

@Controller
public class QueryController {
	@Autowired
	QueryService service;

	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public String updateEmp(@ModelAttribute("qury") Queryy queryy, Map<String, Object> model) {
		return "search";
	}

	@RequestMapping(value = "/search", method = RequestMethod.POST)
	public ModelAndView update(@ModelAttribute("qury") Queryy queryy, Map<String, Object> model) {
		Queryy queryy2 = service.findQuery(queryy.getId());
		if (queryy2 == null) {
			return new ModelAndView("error", "query_id", queryy.getId());
		} else {
			return new ModelAndView("update", "update_query", queryy2);
		}
	}

	@RequestMapping(value = "/updateQuery", method = RequestMethod.POST)
	public ModelAndView updateQuery(@ModelAttribute("qury") Queryy queryy, Map<String, Object> model) {
		service.updateQuery(queryy);
		return new ModelAndView("success", "query_id", queryy.getId());

	}

}
