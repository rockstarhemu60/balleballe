package com.capg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capg.dto.Queryy;

@Repository

public class QueryDAOImpl implements QueryDAO {

	@Autowired
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public Queryy searchQuery(int id) {

		return entityManager.find(Queryy.class, id);

	}

	@Override
	public void updateQueryDao(Queryy queryy) {
		entityManager.merge(queryy);
	}

}
