package com.capg.dao;

import com.capg.dto.Queryy;

public interface QueryDAO {

	public Queryy searchQuery(int id);

	public void updateQueryDao(Queryy queryy);
}
