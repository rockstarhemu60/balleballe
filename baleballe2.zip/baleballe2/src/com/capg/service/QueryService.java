package com.capg.service;

import com.capg.dto.Queryy;

public interface QueryService {
	
	public Queryy findQuery(int id);

	public void updateQuery(Queryy queryy);

}
