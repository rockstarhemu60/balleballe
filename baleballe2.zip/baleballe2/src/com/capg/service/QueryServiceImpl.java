package com.capg.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.dao.QueryDAO;
import com.capg.dto.Queryy;

@Service
@Transactional
public class QueryServiceImpl implements QueryService {

	@Autowired
	QueryDAO dao;

	@Override
	public Queryy findQuery(int id) {
		// TODO Auto-generated method stub
		return dao.searchQuery(id);
	}

	@Override
	public void updateQuery(Queryy queryy) {
		dao.updateQueryDao(queryy);
		
	}

	
	
	

}
