package com.capg.dto;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

@Entity
public class Queryy {

	@Id
	private int id;
	@NotNull
	private String technology;
	@NotNull
	private String query_raised_by;
	@NotNull
	private String query;
	private String solutions;
	private String solutions_given_by;

	public Queryy() {
		// TODO Auto-generated constructor stub
	}

	public Queryy(int id, String technology, String query_raised_by, String query, String solutions,
			String solutions_given_by) {
		this.id = id;
		this.technology = technology;
		this.query_raised_by = query_raised_by;
		this.query = query;
		this.solutions = solutions;
		this.solutions_given_by = solutions_given_by;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTechnology() {
		return technology;
	}

	public void setTechnology(String technology) {
		this.technology = technology;
	}

	public String getQuery_raised_by() {
		return query_raised_by;
	}

	public void setQuery_raised_by(String query_raised_by) {
		this.query_raised_by = query_raised_by;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public String getSolutions() {
		return solutions;
	}

	public void setSolutions(String solutions) {
		this.solutions = solutions;
	}

	public String getSolutions_given_by() {
		return solutions_given_by;
	}

	public void setSolutions_given_by(String solutions_given_by) {
		this.solutions_given_by = solutions_given_by;
	}

}
